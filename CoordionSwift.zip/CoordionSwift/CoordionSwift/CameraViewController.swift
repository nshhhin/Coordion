//
//  CameraViewController.swift
//  CoordionSwift
//
//  Created by 新納真次郎 on 2017/11/10.
//  Copyright © 2017年 nshhhin. All rights reserved.
//

import UIKit
import AVFoundation

class CameraViewController: UIViewController {
  
  @IBOutlet weak var ActivityIndicator: UIActivityIndicatorView!
  @IBOutlet weak var LoadingLabel: UILabel!
  @IBOutlet weak var LoadingView: UIView!
  @IBOutlet weak var myVideoView: UIView!
  var mySession : AVCaptureSession!
  var myDevice : AVCaptureDevice!
  var myImageOutput: AVCapturePhotoOutput!
  var cameraDevice: AVCaptureDevice!
  var isBack = true
  var global: AppDelegate!
  @IBOutlet weak var successImage: UIImageView!
  
  override func viewDidLoad() {
    super.viewDidLoad()
    global = UIApplication.shared.delegate as! AppDelegate
    runCapture()
    
  }
  
  override func didReceiveMemoryWarning() {
    super.didReceiveMemoryWarning()
    // Dispose of any resources that can be recreated.
  }
  
  func runCapture(){
    // セッションの作成.
    mySession = AVCaptureSession()
    let devices = AVCaptureDevice.devices()
    for device in devices {
      // isBack == True  -> Back Camera
      // iSBack == False -> Front Camera
      let devicePosition: AVCaptureDevice.Position = isBack ? .back : .front
      if (device as AnyObject).position == devicePosition {
        self.cameraDevice = device as! AVCaptureDevice
      }
    }
    
    // バックカメラからVideoInputを取得.
    let videoInput = try! AVCaptureDeviceInput.init(device: cameraDevice!)
    // セッションに追加.
    mySession.addInput(videoInput)
    
    // 出力先を生成.
    myImageOutput = AVCapturePhotoOutput()
    // セッションに追加.
    mySession.addOutput(myImageOutput)
    
    // 画像を表示するレイヤーを生成.
    let myVideoLayer = AVCaptureVideoPreviewLayer.init(session: mySession)
    myVideoLayer.frame = myVideoView.bounds
    myVideoLayer.videoGravity = AVLayerVideoGravity.resizeAspectFill
    myVideoView.layer.addSublayer(myVideoLayer)
    
    // セッション開始.
    mySession.startRunning()
  }
  
  @IBAction func tapCameraButton(_ sender: Any) {
    mySession.stopRunning()
    
    ActivityIndicator.startAnimating()
    LoadingView.isHidden = false
    
    // mysqlに服IDを送信し，V-A値を取得する
    
    let postString = "v=\(0.11)&a=\(0.11)"
    // APIに取得したV-A値を送信し，プレイリストを取得する
    var request = URLRequest(url: URL(string: "http://aramasa.nkmr.io/cordion")!)
    request.httpMethod = "POST"
    request.httpBody = postString.data(using: .utf8)
    let task = URLSession.shared.dataTask(with: request, completionHandler: { (data, response, error) in
      if error != nil {
        print(error)
        return
      }
      print("response: \(response!)")
      let phpOutput = String(data: data!, encoding: .utf8)!
      do {
        let dic_array = try JSONSerialization.jsonObject(with: data!, options: []) as! [Dictionary<String,String>]
        self.ActivityIndicator.stopAnimating()
        self.ActivityIndicator.isHidden = true
        self.successImage.isHidden = false
        self.global.playlist = dic_array
        let next = self.storyboard!.instantiateViewController(withIdentifier: "TabBarView")
        next.modalTransitionStyle = .crossDissolve
        self.present(next,animated: true, completion: nil)
      } catch {
        print(error.localizedDescription)
        let next = self.storyboard!.instantiateViewController(withIdentifier: "TabBarView")
        next.modalTransitionStyle = .crossDissolve
        self.present(next,animated: true, completion: nil)
      }
     
      
      
    })
    task.resume()
  }
  
  @IBAction func tapUndoButton(_ sender: Any) {
    dismiss(animated: true)
    mySession.stopRunning()
  }
  
  @IBAction func changedSwitch(_ sender: Any) {
    switch (sender as AnyObject).selectedSegmentIndex {
    case 0:
      print("背面")
      isBack = true
      runCapture()
    case 1:
      print("正面")
      isBack = false
      runCapture()
    default:
      print("")
    }
  }
  
}
